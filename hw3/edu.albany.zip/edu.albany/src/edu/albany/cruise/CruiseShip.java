package edu.albany.cruise;

import edu.albany.Ship;

public class CruiseShip extends Ship {
	private int max;

	public CruiseShip() {
		max = 0;
	}
	
	public CruiseShip(int m) {
		max = m;
	}
	
	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}
	
	public String toString() {
		return "The Cruise Ship " + this.getName() + " can hold " + max + " passengers.";
	}
}

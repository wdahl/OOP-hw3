package edu.albany.sandwichShop;

public class Cashier {
	private Customer customer;
	private double payment;
	
	public enum Sandwich{
		HAM("Ham", 5.00), 
		TURKEY("Turkey", 5.00), 
		ITALIN("Italin", 6.00), 
		BUFFCHK("Buffalo Chicken", 7.00), 
		MEATBALL("Meatball", 6.00), 
		BLT("BLT", 4.00), 
		RUBEN("Ruben", 8.00),
		CUSTOM(8.50);
		
		private double price;
		private String name;
		
		Sandwich(String name, double cost) {
			this.name = name;
			price = cost;
		}
		
		Sandwich(double cost){
			price = cost;
		}
		
		public double getPrice(){
			return price;
		}
		
		public String getName() {
			return name;
		}
	};
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

	public double getPayment() {
		return payment;
	}

	public void setPayment(double payment) {
		this.payment = payment;
	}
	
	public double charge() {
		switch(customer.getOrder()) {
			case "Ruben":
				return Sandwich.RUBEN.getPrice();
		
			case "Turkey":
				return Sandwich.TURKEY.getPrice();
			
			case "Italin":
				return Sandwich.ITALIN.getPrice();
				
			case "Buffalo Chicken":
				return Sandwich.BUFFCHK.getPrice();
				
			case "Meatball":
				return Sandwich.MEATBALL.getPrice();
				
			case "BLT":
				return Sandwich.BLT.getPrice();
				
			case "Ham":
				return Sandwich.HAM.getPrice();
				
			default:
				return Sandwich.CUSTOM.getPrice();
		}
	}
	
	public void giveChange() {
		if((payment-this.charge()) < 0) {
			System.out.println("payment provided is not enough for the sandwich ordered.");
			System.exit(0);
		}
		else {
			Customer.getChange(payment - this.charge());
		}
	}
}

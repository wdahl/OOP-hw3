package edu.albany.sandwichShop;

public class SandwhichDriver {
	public static void main(String[] args) throws InterruptedException {
		Customer customer = new Customer("Will", "Tuna", 20);
		Cashier cashier = new Cashier();
		SandwhichMaker sandwhichMaker = new SandwhichMaker();
		
		customer.customerStatus();
		
		cashier.setCustomer(customer);
		cashier.setPayment(customer.pay(8.50));
		cashier.giveChange();
		
		sandwhichMaker.setCustomer(cashier.getCustomer());
		sandwhichMaker.makeSandwich();
		sandwhichMaker.giveSandwhich();
		
		customer.customerStatus();
	}
}

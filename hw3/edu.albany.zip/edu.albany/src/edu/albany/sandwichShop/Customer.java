package edu.albany.sandwichShop;

public class Customer {
	private String name;
	private String order;
	private static double money;
	private boolean hungry = true;
	
	public Customer() {
		name = null;
		order = null;
		money = 0.0;
	}
	
	public Customer(String n, String o, double m) {
		name = n;
		order = o;
		money = m;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getOrder() {
		return order;
	}
	
	public void setOrder(String order) {
		this.order = order;
	}
	
	public double getMoney() {
		return money;
	}
	
	public void setMoney(double money) {
		Customer.money = money;
	}
	
	public double pay(double cost) {
		money -= cost;
		return cost;
	}
	
	public static void getChange(double change) {
		money += change;
	}
	
	public void givenSandwhich() {
		hungry = false;
	}
	
	public String toString() {
		if(hungry) {
			return "Customer: " + name + "\nStatus: hungry\nMoney: $" + String.format("%.2f", money);
		}
		
		return "Customer: " + name + "\nStatus: full\nMoney: $" + String.format("%.2f", money);
	}
	
	public void customerStatus() {
		System.out.println(this);
	}
}

package edu.albany.sandwichShop;

public class SandwhichMaker {
	private Customer customer;
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public void makeSandwich() throws InterruptedException {
		System.out.println("Preparing " + customer.getOrder() + " for " + customer.getName());
		Thread.sleep(5000);
		System.out.println("Order up for " + customer.getName() + "!");
	}
	
	public void giveSandwhich() {
		customer.givenSandwhich();
	}
}

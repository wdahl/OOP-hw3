package edu.albany;

public class Ship {
	private String name;
	private String year;
	
	public Ship() {
		name = null;
		year = null;
	}
	
	public Ship(String n, String y) {
		name = n;
		year = y;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getYear() {
		return year;
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	
	public String toString() {
		return "The ship " + name + " was built in " + year + ".";
	}
}

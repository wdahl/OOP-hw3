package edu.albany;

import edu.albany.cargo.CargoShip;
import edu.albany.cruise.CruiseShip;

public class ShipDriver {
	public static void main(String[] args) {
		Ship ship = new Ship("The Titanic", "1899");
		
		CruiseShip cruise = new CruiseShip(5000);
		cruise.setName("USS Mickey");
		cruise.setYear("1904");
		
		CargoShip cargo = new CargoShip(1000);
		cargo.setName("The Chasey Wasey");
		cargo.setYear("1998");
		
		Ship[] shipArray = {ship, cruise, cargo};
		
		for(Ship e: shipArray) {
			System.out.println(e);
		}
	}
}

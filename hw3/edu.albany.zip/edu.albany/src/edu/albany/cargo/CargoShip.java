package edu.albany.cargo;

import edu.albany.Ship;

public class CargoShip extends Ship {
	private int capacity;

	public CargoShip() {
		capacity = 0;
	}
	
	public CargoShip(int c) {
		capacity = c;
	}
	
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public String toString() {
		return "The Cargo ship " + this.getName() + " has a capacity of " + capacity + ".";
	}
}
